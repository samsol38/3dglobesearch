

const Color = {

};

export default Color;