

const Strings = {

    /*  Master Drawer Main Menu Title    */


    /*  Master Module Title    */


    /*  Module Title    */


};

export default Strings;