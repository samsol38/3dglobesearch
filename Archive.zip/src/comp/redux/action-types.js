export const SET_USER_CONFIG = 'SET_USER_CONFIG';
export const SET_USER_PREF = 'SET_USER_PREF';
