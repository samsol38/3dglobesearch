import React, {
    Fragment,
    useState,
    useEffect,
    useRef
} from 'react';

import {
    useDisclosure,
    useColorMode,
    Heading,
    Box,
    Text,
    Flex,
    Button,
    IconButton,
    Accordion,
    AccordionItem,
    AccordionButton,
    AccordionIcon,
    AccordionPanel,
    Code,
    Divider
} from "@chakra-ui/react"

import {
    HamburgerIcon,
    MoonIcon,
    SunIcon
} from '@chakra-ui/icons'

import {
    connect
} from 'react-redux';

import lodash from 'lodash';

import Actions from '../../redux/action';
import Constants from '../../utils/Constants';

import PhoneNumArray from '../../data/info/phone-num.json';
import PostalCodeArray from '../../data/info/postal-codes.json';

const {
    PlaceType
} = Constants;

const MasterPlaceConfig = {
    [PlaceType.Country]: {
        name: {
            title: 'Name'
        },
        native: {
            title: 'Native Name'
        },
        capital: {
            title: 'Capital'
        },
        region: {
            title: 'Region'
        },
        subregion: {
            title: 'Sub-Region'
        },
        emoji: {
            title: 'Emoji'
        },
        emojiU: {
            title: 'EmojiU'
        },
        iso3: {
            title: 'ISO3'
        },
        iso2: {
            title: 'ISO2'
        },
        tld: {
            title: 'Domain'
        },
        currency_name: {
            title: 'Currency Name'
        },
        currency: {
            title: 'Currency Code'
        },
        currency_symbol: {
            title: 'Currency Symbol'
        },
        numeric_code: {
            title: 'Numeric Code'
        },
        phone_code: {
            title: 'Phone Code'
        },
    }
}

const TimeZoneConfig = {
    zoneName: {
        title: 'Zone'
    },
    gmtOffset: {
        title: 'GMT Offset'
    },
    gmtOffsetName: {
        title: 'UTC Offset'
    },
    abbreviation: {
        title: 'Short Form'
    },
    tzName: {
        title: 'Full Form'
    }
}

const PlaceInfoView = (props) => {

    const {
        userConfig,
        placeItem
    } = props;

    const [state, setState] = useState({
        placeDetailsObj: null,
        countryDetailsObj: null,
        timeZoneArray: [],
        defaultIndex: [0]
    });

    const updateState = (data) =>
        setState((preState) => ({ ...preState, ...data }));

    /*  Life-cycles Methods */

    useEffect(() => {
        return () => {
        };
    }, []);

    useEffect(() => {
        showInfo();
    }, [placeItem]);

    /*  Public Interface Methods */

    const showInfo = () => {
        console.log(placeItem)

        if (!lodash.isNil(placeItem)) {
            getPlaceDetails();
        } else {
            updateState({
                placeDetailsObj: null,
                countryDetailsObj: null,
                timeZoneArray: [],
                defaultIndex: [0]
            });
        }
    }

    const getPlaceDetails = () => {
        let placeType = placeItem?.type;
        let placeConfigObj = Object.assign({}, MasterPlaceConfig[placeItem?.type]);
        let placeDetailsObj = {};

        switch (placeType) {
            case PlaceType.Country: {

                setCountryDetails(placeItem);

                placeDetailsObj = {
                    name: {
                        type: 'name',
                        title: 'Name',
                        value: placeItem.name,
                    },
                    placeType: {
                        type: 'placeType',
                        title: 'Place Type',
                        value: 'Country'
                    },
                    latitude: {
                        type: 'latitude',
                        title: 'Latitude',
                        value: placeItem.latitude
                    },
                    longitude: {
                        type: 'longitude',
                        title: 'Longitude',
                        value: placeItem.longitude
                    }
                }

                updateState({
                    placeDetailsObj: placeDetailsObj
                });

                break;
            }

            case PlaceType.State: {

                setCountryDetails(placeItem?.countryItem);

                placeDetailsObj = {
                    name: {
                        type: 'name',
                        title: 'Name',
                        value: placeItem.name,
                    },
                    placeType: {
                        type: 'placeType',
                        title: 'Place Type',
                        value: 'State'
                    },
                    address: {
                        type: 'address',
                        title: 'Address',
                        value: placeItem.address,
                    },
                    stateCode: {
                        type: 'stateCode',
                        title: 'State Code',
                        value: placeItem?.state_code
                    },
                    countryName: {
                        type: 'countryName',
                        title: 'Country',
                        value: placeItem.countryItem?.name,
                    },
                    latitude: {
                        type: 'latitude',
                        title: 'Place Latitude',
                        value: placeItem.latitude
                    },
                    longitude: {
                        type: 'longitude',
                        title: 'Place Longitude',
                        value: placeItem.longitude
                    }
                }

                updateState({
                    placeDetailsObj: placeDetailsObj
                });

                break;
            }

            case PlaceType.City: {

                setCountryDetails(placeItem?.countryItem);

                placeDetailsObj = {
                    name: {
                        type: 'name',
                        title: 'Name',
                        value: placeItem.name,
                    },
                    placeType: {
                        type: 'placeType',
                        title: 'Place Type',
                        value: 'City'
                    },
                    address: {
                        type: 'address',
                        title: 'Address',
                        value: placeItem.address,
                    },
                    latitude: {
                        type: 'latitude',
                        title: 'Place Latitude',
                        value: placeItem.latitude
                    },
                    longitude: {
                        type: 'longitude',
                        title: 'Place Longitude',
                        value: placeItem.longitude
                    },
                    stateName: {
                        type: 'stateName',
                        title: 'State',
                        value: placeItem?.stateItem?.name
                    },
                    stateCode: {
                        type: 'stateCode',
                        title: 'State Code',
                        value: placeItem?.stateItem?.state_code
                    },
                    countryName: {
                        type: 'countryName',
                        title: 'Country',
                        value: placeItem.countryItem?.name,
                    },
                    // stateLatitude: {
                    //     type: 'stateLatitude',
                    //     title: 'State Latitude',
                    //     value: placeItem.stateItem?.latitude
                    // },
                    // stateLongitude: {
                    //     type: 'stateLongitude',
                    //     title: 'State Longitude',
                    //     value: placeItem.stateItem?.longitude
                    // },
                }

                updateState({
                    placeDetailsObj: placeDetailsObj
                });

                break;
            }
        }
    }

    const setCountryDetails = (countryItem) => {

        let placeConfigObj = Object.assign({}, MasterPlaceConfig[PlaceType.Country]);
        let placeDetailsObj = {};

        for (let key in placeConfigObj) {
            if (!lodash.isNil(countryItem[key]) &&
                (lodash.isString(countryItem[key]) &&
                    countryItem[key].trim() !== '')) {
                placeDetailsObj = {
                    ...placeDetailsObj,
                    [key]: {
                        ...placeConfigObj[key],
                        type: key,
                        value: countryItem[key]
                    }
                }
            }
        }

        let phoneNumRegex = getPhoneNumFormat(countryItem);

        if (!lodash.isNil(phoneNumRegex) &&
            (lodash.isString(phoneNumRegex) &&
                phoneNumRegex.trim() !== '')) {

            placeDetailsObj = {
                ...placeDetailsObj,
                phoneNum: {
                    type: 'phoneNum',
                    title: 'Phone Format',
                    value: phoneNumRegex
                }
            }
        }

        let postalCodeObj = getPostalCodeFormat(countryItem);

        if (!lodash.isNil(postalCodeObj)) {

            placeDetailsObj = {
                ...placeDetailsObj,
                zipCodeFormat: {
                    type: 'zipCodeFormat',
                    title: 'ZipCode Format',
                    value: postalCodeObj?.Format
                }
            }

            if (!lodash.isNil(postalCodeObj?.Regex) &&
                (lodash.isString(postalCodeObj?.Regex) &&
                    postalCodeObj?.Regex.trim() !== '')) {
                placeDetailsObj = {
                    ...placeDetailsObj,
                    zipCodeRegex: {
                        type: 'zipCodeFormat',
                        title: 'ZipCode Regex',
                        value: postalCodeObj?.Regex
                    }
                }
            }
        }

        let timeZoneArray = getTimeZones(countryItem);

        updateState({
            countryDetailsObj: placeDetailsObj,
            timeZoneArray: timeZoneArray,
            defaultIndex: [0]
        });
    }


    const getTimeZones = (countryItem) => {
        let timeZoneArray = countryItem?.timezones ?? [];
        let masterTimeZoneArray = [];
        timeZoneArray.forEach((item, index) => {
            let timeZoneObj = {};
            for (let key in item) {
                if (!lodash.isNil(item[key]) &&
                    (lodash.isString(`${item[key]}`) &&
                        `${item[key]}`.trim() !== '')) {
                    timeZoneObj = {
                        ...timeZoneObj,
                        [key]: {
                            ...TimeZoneConfig[key],
                            type: key,
                            value: `${item[key]}`
                        }
                    }
                }
            }
            masterTimeZoneArray.push(timeZoneObj);
        });

        return masterTimeZoneArray;
    }

    const getPhoneNumFormat = (countryItem) => {
        let phoneNumArray = PhoneNumArray.slice();
        let countryCode = countryItem.iso2;
        let phoneNumRegex = null;

        let filteredPhoneNumArray = phoneNumArray.filter((item) => {
            return item[1].toLowerCase() === countryCode.toLowerCase()
        });

        if (filteredPhoneNumArray.length > 0) {
            phoneNumRegex = filteredPhoneNumArray[0][3];
        }

        return phoneNumRegex
    }

    const getPostalCodeFormat = (countryItem) => {
        let postalCodeArray = PostalCodeArray.slice();
        let countryCode = countryItem.iso2;
        let postalCodeObj = null;

        let filteredPostalCodeArray = postalCodeArray.filter((item) => {
            return item.ISO.toLowerCase() === countryCode.toLowerCase()
        });


        if (filteredPostalCodeArray.length > 0) {
            postalCodeObj = filteredPostalCodeArray[0];
        }

        return postalCodeObj
    }

    /*  UI Events Methods   */

    /*  Server Request Methods  */

    /*  Server Response Methods  */

    /*  Server Response Handler Methods  */

    /*  Custom-Component sub-render Methods */

    const renderPlaceProperty = (propertyItem, index) => {
        return (
            <Flex
                key={`${index}`}
                flexDirection='row'
                alignItems={'center'}
                justifyContent={'space-between'}
                mb={2}>
                <Text fontSize={'sm'}>{`${propertyItem.title}`}</Text>
                <Flex
                    justify={'center'}
                    alignItems={'center'}
                    // height={1}
                    flexGrow={1}
                    marginX={'5px'}
                ><Divider zIndex={0} /></Flex>
                <Code
                    fontSize={'sm'}
                    textAlign={'right'}
                    colorScheme='linkedin'>{`${propertyItem.value.trim()}`}</Code>
            </Flex>
        )
    }

    const renderTimeZoneProperty = (propertyItem, index) => {
        return (
            <>
                <Flex
                    key={`${index}`}
                    flexDirection='row'
                    alignItems={'center'}
                    justifyContent={'space-between'}
                    mb={2}>
                    <Text fontSize={'sm'}>{`${propertyItem.title}`}</Text>
                    <Flex
                        justify={'center'}
                        alignItems={'center'}
                        // height={1}
                        flexGrow={1}
                        marginX={'5px'}
                    ><Divider zIndex={0} /></Flex>
                    <Code
                        fontSize={'sm'}
                        textAlign={'right'}
                        colorScheme='linkedin'>{`${propertyItem.value.trim()}`}</Code>
                </Flex>
            </>
        )
    }

    const renderPlaceInfo = () => {
        return (
            <Accordion
                flex={1}
                overflowX={'hidden'}
                // width={`25vw`}
                allowMultiple
                defaultIndex={[0]}>
                <AccordionItem>
                    <AccordionButton
                        bg={'gray.100'}>
                        <Box width={'100%'} fontSize={'md'}
                            fontWeight={'medium'} textAlign='left'>
                            {`Place Details - ${placeItem.name}`}
                        </Box>
                        <AccordionIcon />
                    </AccordionButton>
                    <AccordionPanel>
                        <Box>
                            {Object.keys(state?.placeDetailsObj).map((item, index) => {
                                return renderPlaceProperty(state?.placeDetailsObj[item], index)
                            })}
                        </Box>

                    </AccordionPanel>
                </AccordionItem>
                <AccordionItem>
                    <AccordionButton
                        bg={'gray.100'}>
                        <Box width={'100%'} fontSize={'md'}
                            fontWeight={'medium'} textAlign='left'>
                            Country Details
                        </Box>
                        <AccordionIcon />
                    </AccordionButton>
                    <AccordionPanel
                    >
                        <Box>
                            {Object.keys(state?.countryDetailsObj).map((item, index) => {
                                return renderPlaceProperty(state?.countryDetailsObj[item], index)
                            })}
                        </Box>

                    </AccordionPanel>
                </AccordionItem>
                <AccordionItem
                    overflowY={'auto'}>
                    <AccordionButton
                        bg={'gray.100'}>
                        <Box width={'100%'} fontSize={'md'}
                            fontWeight={'medium'} textAlign='left'>
                            {`TimeZone Details - (${state?.timeZoneArray.length})`}
                        </Box>
                        <AccordionIcon />
                    </AccordionButton>
                    <AccordionPanel>
                        {(state?.timeZoneArray ?? []).map((timezoneObj, index) => {
                            return (
                                <Box
                                    paddingY={1}>
                                    {(state?.timeZoneArray ?? []).length > 1 &&
                                        <Text
                                            as='u'
                                            fontWeight={'medium'}
                                            align={'center'}
                                            fontSize={'md'}>{`TimeZone ${index + 1}`}</Text>}
                                    <Box
                                        mt={2}>
                                        {Object.keys(timezoneObj).map((item, index) => {
                                            return renderTimeZoneProperty(timezoneObj[item], index)
                                        })}
                                    </Box>
                                    {index < (state?.timeZoneArray ?? []).length - 1 &&
                                        <Divider zIndex={0} />}
                                </Box>);
                        })}
                    </AccordionPanel>
                </AccordionItem>
            </Accordion>
        )
    }

    const renderMasterContainer = () => {
        return (
            <>
                <Flex
                    flexShrink={1}
                    minWidth={'100%'}
                    maxHeight={'80vh'}
                    overflow={'hidden'}
                    // width={`25vw`}
                    bg={'chakra-body-bg'}
                    borderRadius={'5px'}
                    mt={2}>
                    {!lodash.isNil(state?.countryDetailsObj) &&
                        renderPlaceInfo()}
                </Flex>
            </>
        )
    }

    return renderMasterContainer()
};

const mapStateToProps = state => {
    return {
        userConfig: state.userConfig,
        userPref: state.userPref,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        setUserConfig: (userConfig) => dispatch(Actions.setUserConfig(userConfig)),
        setUserPref: (userPref) => dispatch(Actions.setUserPref(userPref))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(PlaceInfoView);
